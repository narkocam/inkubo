# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Plugin Tools v1.0.8
#---------------------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube, parsedom and pelisalacarta addons
# Author: "torete"
# Jesús
# tvalacarta@gmail.com
# http://www.mimediacenter.info/plugintools
#---------------------------------------------------------------------------

import plugintools

myaddon =xbmcaddon .Addon ()

def run():
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec (action+"(params)")
    
    plugintools.close_item_list()
 

def main_list(params):
    
    
    plugintools.add_item(action = "hittv" , title = "[B][LOWERCASE][CAPITALIZE][COLOR white] Hit[/COLOR] [COLOR red]TV [/CAPITALIZE][/LOWERCASE][/B][/COLOR]", thumbnail ="https://peliculasflix.co/wp-content/uploads/2020/07/logo-peliculasflix.png?x64592",fanart = "https://peliculasflix.co/wp-content/uploads/2020/07/logo-peliculasflix.png?x64592",url="http://www.hittv.es/", folder=False,isPlayable=True )

def hittv(params):
    url='http://www.hittv.es/reelhittv.mp4'
    xbmc.log('444444444444444 .> '+str(url))
    plugintools.play_resolved_url(url+'|user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0&referer='+ params.get('url'))

    
run() 

    

